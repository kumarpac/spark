from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("mapValue example").getOrCreate()

def parseLine(lines):
    fields = lines.split(',')
    age = int(fields[2])
    numFriends = int(fields[3])
    return (age,numFriends)

lines = spark.sparkContext.textFile("C:/input/fakefriends.csv")
rdd = lines.map(parseLine)
#-----to display the rdd's data ----------
# for data in rdd.collect():
# #     print(data)
mapdata = rdd.mapValues(lambda e1:(e1,1))
totalByAge = mapdata.reduceByKey(lambda x,y:(x[0] + y[0],x[1] + y[1]))
for data in totalByAge.collect():
    print("Age of {} has number of Friends {} ".format(data[0],data[1][0]))
#find the average
averageByagae= totalByAge.mapValues(lambda e1:(e1[0]/e1[1]))
results =averageByagae.collect()
for result in results:
    print(result)