def bubbleSort(arr):
    n=len(arr)
    for i in range(n-1):
       # print(i)
        for j in range(n-i-1):
            if(arr[j]>arr[j+1]):
                tmp = arr[j]
                arr[j] = arr[j+1]
                arr[j+1] =  tmp
ar=[0,0,1,1,2,0,90]
#ar.sort()
bubbleSort(ar)
print("sorted array is")
for i in range(len(ar)):
    print(ar[i])



