import csv
import os

with open("C:/input/employee.csv") as f:
    reader = csv.reader(f,skipinitialspace=True)
    for row in reader:
        print(row)