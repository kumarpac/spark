from pyspark.sql import SparkSession
import datetime

spark = SparkSession.builder.appName("flatmap testing").config("spark.scheduler.mode", "FAIR").getOrCreate()
data = spark.sparkContext.textFile("C:/input/flatmap.txt")

dataT = spark.sparkContext.textFile("C:/input/flatmap.txt")

print(data.collect())
acc = spark.sparkContext.accumulator(0)
print("---- Custom Spark Job Metrix -------")
user = spark.sparkContext.sparkUser()
print("Application User: {} ".format(user))
appname = spark.sparkContext.appName
print("Application Name: {} ".format(appname))
start_time = spark.sparkContext.startTime

x = datetime.datetime.fromtimestamp(start_time / 1000.0)
print("Application Uptime: {}  ".format(x))
y = spark.conf.get("spark.scheduler.mode")
print("Spark Scheduler: {}".format(y))
dd = spark.sparkContext.statusTracker()
dd1 = spark.sparkContext.statusTracker.getActiveJobsIds()
# l = []
# for i in dd1:
#     l.append(i)
# print(l)
