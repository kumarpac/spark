from pyspark.sql import SparkSession
import pyspark.sql.functions as F
spark = SparkSession.builder.appName("new column adding in data frame").getOrCreate()
df = spark.read.csv("C:/input/u.data",sep="\t",inferSchema="true",header="false")

df1 =df.toDF(*['user_id', 'movie_id', 'rating', 'unix_timestamp'])

df1.show()

df2_with_new_column=df1.withColumn("new_timesstamp",F.substring("unix_timestamp",0,3))

df2_with_new_column.show()