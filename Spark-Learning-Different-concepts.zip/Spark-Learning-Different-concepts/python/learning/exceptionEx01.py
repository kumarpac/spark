x = "hello"

if not type(x) is int:
    raise TypeError("only integer allowed")