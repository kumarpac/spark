from pyspark.sql import SparkSession
from pyspark.sql.types import Row
spark = SparkSession\
    .builder\
    .master("local[2]")\
    .appName("Python Spark SQL examples")\
    .config("spark","value")\
    .getOrCreate()
lookup = {"This":"frequent","is":"frequent","my":"moderate","file":"rare"}

data = spark.sparkContext.parallelize(lookup).map(lambda x:(x,lookup[x]))
print(data.collect())
num = range(0,10)

data1 = spark.sparkContext.parallelize(num).map(lambda x:(x,x)).partitionBy(2).persist()
print("number of partitions {} ".format(data1.getNumPartitions()))
print("partitioner {} ".format(data1.partitioner))
print("partitioner structure {} ".format(data1.glom().collect()))
