from pyspark import SparkContext
sc = SparkContext("local")

def linesParser(line):
    fields = line.split(",")
    age = int(fields[2])
    numFriends = int(fields[3])
    return (age,numFriends)


lines=sc.textFile("C://Users//pawan.kumar//PycharmProjects//untitled//fakefriends.csv")
linesrdd = lines.map(linesParser)
flatw = linesrdd.flatMap(lambda x:x)
for i in flatw.collect():
    print(i)
#linesrdd.foreach(print)