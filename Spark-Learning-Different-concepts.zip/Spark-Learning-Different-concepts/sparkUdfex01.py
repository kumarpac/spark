from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import *
spark = SparkSession.builder.appName("new column adding in data frame").getOrCreate()
def somefunc(value):
    if value < 3:
        return 'low'
    else:
        return 'high'

udfsomefun = F.udf(somefunc,StringType())