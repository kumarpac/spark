import pandas as pd

#read csv  file
#df = pd.read_csv("C:\\Users\\pawan.kumar\\PycharmProjects\\untitled\\temperature.csv")
#print(df)
weather_data = {
    'day':['1/1/2020','1/2/2020','1/3/2020','1/4/2020','1/5/2020','1/6/2020'],
    'temperature':[32,35,28,24,32,31],
    'windspeed':[6,7,2,7,4,2],
    'event':['Rain','Sunny','Snow','Snow','Rain','Sunny']
}
df = pd.DataFrame(weather_data)
print(df)
row, columns = df.shape
print(row,'-->',columns)
print(df.head())
print(df.tail(1))
print(df[2:5])
print(df[:])
print(df.columns)
print(df.day)