from pyspark.sql import SparkSession
from pyspark.sql import Row

spark = SparkSession.builder.appName("Repartition example").getOrCreate()
nums = range(0,10)
data = spark.sparkContext.parallelize(nums).map(lambda e1:(Row(e1)))
nums_df = spark.createDataFrame(data, ['num'])
print(nums_df.collect())
