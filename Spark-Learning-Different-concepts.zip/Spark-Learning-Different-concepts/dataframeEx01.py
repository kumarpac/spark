from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import *
spark = SparkSession.builder.appName("flatmap testing").getOrCreate()
#Creating data frame from rdd
data2 = spark.sparkContext.parallelize([Row(userid=1,username='user1',date='20-04-2018'),Row(userid=1,username='user1',date='20-04-2019')])
df = data2.toDF()
df.show()
#Creating data frame from rdd 2nd method
data1 = spark.sparkContext.parallelize([Row(1,'user1','20-04-2018'),Row(2,'user1','20-04-2019')])
schema = StructType([StructField("id",IntegerType()),StructField("username",StringType()),StructField("date",StringType())])
df1 = spark.createDataFrame(data1,schema)
df1.createOrReplaceTempView("employee")
spark.sql("select * from employee").show()