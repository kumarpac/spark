from pyspark import SparkConf, SparkContext
#conf = SparkConf('local')
sc = SparkContext('local')
lines = sc.textFile("C://Users//pawan.kumar//PycharmProjects//untitled//u.data")
ratings = lines.map(lambda x:x.split())
print((ratings.take(2)))