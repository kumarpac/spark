import re
pattern = re.compile(r'(,\s){2,}')
vr = "email   string"
result = re.sub(pattern,',',vr)
print(result)