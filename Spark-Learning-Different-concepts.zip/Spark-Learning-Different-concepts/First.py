def check():
    x="Stop"
    while x!="Running":
        print(x)
        x= input("Enter state=Running")

if __name__ =='__main__':
    check()

















