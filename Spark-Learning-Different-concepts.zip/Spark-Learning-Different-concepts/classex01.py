class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
    def myfunc(self):
        print("hello my name is: {} ".format(self.name))

person = Person("Pawan",36)
#print(person.age)
#print(person.name)
person.myfunc()