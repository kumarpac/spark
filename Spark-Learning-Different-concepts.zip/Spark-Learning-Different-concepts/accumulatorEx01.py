from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("flatmap testing").getOrCreate()
#data = spark.sparkContext.parallelize([1,2])
#print(data.collect())
acc = spark.sparkContext.accumulator(0)
wordCount = spark.sparkContext.accumulator(0)
print(acc.value)
def blanklines(lines):
    if len(lines) == 0:
        acc.add(1)

data = spark.sparkContext.textFile("C:/input/flatmap.txt")
accdata = data.foreach(lambda x:blanklines(x))
print(data.collect())
print(wordCount.value)
#countword = data.map(lambda x:(wordCount.value[x] +=1]))
# accdata1 = data2.foreach(lambda x:(wordCount.add(x)))
# print(wordCount.value)