from datetime import datetime, timedelta
'''
dateList = []
for x in range(14, 1, -1):
    d = datetime.today() - timedelta(days=x)
    dateList.append(d.strftime('%Y%m%d'))
print(dateList)
'''
'''
for i in range(14,1,-1):
    print(i)
'''
d = datetime.today()-timedelta()
d1 = timedelta(days=1)
d_d1=datetime.today()-timedelta(days=14)
print(d)
print(d1)
print(d_d1)