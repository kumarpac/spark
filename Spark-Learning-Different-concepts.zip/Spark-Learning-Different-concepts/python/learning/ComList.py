import numbers
def foo(data):
    emp = []
    for x in data:
        if isinstance(x,numbers.Number):
         emp.append(x)
    return emp

data = foo([99, 'no data', 95, 94, 'no data'])
print(data)