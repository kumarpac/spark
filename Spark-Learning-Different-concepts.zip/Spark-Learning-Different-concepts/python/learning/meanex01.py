def mean(mylist):
    if type(mylist) == dict:
       the_mean = sum(mylist.values())/len(mylist.values())
    else:
        the_mean = sum(mylist) / len(mylist)
    return the_mean

if __name__ == "__main__":
    result = mean([1,2,3,4])
    keyValue = {"a":20,"b":10,"c":10}
    dicResult= mean(keyValue)
    print(result)
    print(dicResult)
print("hello")