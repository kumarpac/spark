
import datetime
str = '1583288658808'


import time
#time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(1583288658808))
import datetime
d = datetime.datetime.fromtimestamp(1347517370).strftime('%c')
print(d)