from pyspark.sql import SparkSession
from pyspark.sql import Row

spark = SparkSession.builder.appName("BroadCast example").getOrCreate()
num = [1,2,3,4,5]

br = spark.sparkContext.broadcast(num)
print(br.value)
data = spark.sparkContext.parallelize(num).flatMap(lambda e1:br.value).collect()

print(data)