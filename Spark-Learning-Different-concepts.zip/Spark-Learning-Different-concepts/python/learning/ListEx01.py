#Prime number checking
#num = int(input("Enter the number to check"))
# if num > 1:
#     for i in range(2,num):
#         #Checking for factor
#         if (num % i == 0):
#             print(num,"is not a prime number")
#             print(i,"times",num//i,"is",num)
#             break
#         else:
#             print(num,"is a prime number")
# else:
#     print(num, "is not a prime number")

# while loop example
# num = 0
# while num < 6:
#     print(num)
#     num +=1
# friend_list = []
# while True:
#     user_input = input("Enter the name of your friends\n enter quite to not recommend any one of your friend name ")
#     if user_input == 'quite':
#         break
#     else:
#         friend_list.append(user_input)
#         continue
# print("Check your memory \n you entered {}".format(len(friend_list)))
# print("Your friends are \n",friend_list)


programmer_name = ["Ravi","Pradeep","Vijay","Pihu"]
favorite_language = ["Python 2.7","PowerShell 5.0","Python 3.7","Java"]
years_experience =[4,5,6,5]

for programmer_name, favorite_language,years_experience in zip(programmer_name, favorite_language,years_experience):
    print(programmer_name,years_experience)