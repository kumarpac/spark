from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("mapValue example").getOrCreate()

def parseLine(lines):
    fields = lines.split(',')
    stationID = fields[0]
    maxTemp = fields[2]
    tmperature = float(fields[3])*0.1*(9.0/5.0) +32.0
    return (stationID,maxTemp,tmperature)

lines = spark.sparkContext.textFile("C:/input/1800.csv")
rdd = lines.map(parseLine)
mintmp = rdd.filter(lambda e1:'TMIN' in e1)
sttemp = mintmp.map(lambda e1:(e1[0],e1[2]))
mintemperature = sttemp.reduceByKey(lambda x,y:(min(x,y)))
for result in mintemperature.collect():
    print(result[0]+ "\t {:.2f}F".format(result[1]))