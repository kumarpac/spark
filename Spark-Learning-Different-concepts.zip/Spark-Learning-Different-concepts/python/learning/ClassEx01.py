class Dog:
    species = 'mamal'
    def __init__(self,bread,name,spot):
        self.bread = bread
        self.name = name
        self.spot = spot
    def bark(self):
        print("wolf!! my name is {} ".format(self.name))
my_dog = Dog(bread="Lab",name="Sammy",spot=True)
print(my_dog.bread)
print(my_dog.name)
print(my_dog.spot)
print(my_dog.bark())
