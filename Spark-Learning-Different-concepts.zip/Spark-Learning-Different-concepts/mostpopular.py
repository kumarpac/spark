from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("find the popular movies").getOrCreate()
def parseNames(line):
    fields = line.split('\"')
    return (int(fields[0]),fields[1].encode("utf8"))
def countCoOccurence(line):
    elements = line.split()
    return (int(elements[0]),len(elements)-1)
names = spark.sparkContext.textFile("C:/input/marvel_name.txt")
namesrdd = names.map(parseNames)

lines = spark.sparkContext.textFile("C:/input/marvel_graph.txt")
pairing =lines.map(countCoOccurence)
totalFriendsByCharacter = pairing.reduceByKey(lambda x,y:(x+y))
flipped = totalFriendsByCharacter.map(lambda x:(x[1],x[0]))
mostpopular = flipped.max()
#print(mostpopular)
mostpopularName = namesrdd.lookup(mostpopular[1][0])
print(str(mostpopularName))