from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("find the popular movies").getOrCreate()


def employeeDetails():
    empname = {}
    with open("C:/input/u.ITEM") as f:
        for line in f:
            fields = line.split('|')
            empname[int(fields[0])] = fields[1]
    print(empname)
    return empname


bc = spark.sparkContext.broadcast(employeeDetails())
#print(bc.value())
lines = spark.sparkContext.textFile("C:/input/u.data")
movies = lines.map(lambda e1:(int(e1.split()[1]),1))
#for result in movies.collect():
#    print(result)

movieCount = movies.reduceByKey(lambda x,y:(x+y))
flipped = movieCount.map( lambda x:(x[1],x[0]))
sorteddata = flipped.sortByKey()

# for result in sorteddata.collect():
#     print(result)

mapdatawithname = sorteddata.map(lambda countm:(bc.value[countm[1]],countm[0]))
results = mapdatawithname.collect()
for result in results:
     print(result)