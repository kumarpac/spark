from pyspark import SparkContext
sc = SparkContext('local')
words = sc.parallelize(["scala","java","hadoop","spark","akka"])
#lines = sc.textFile("C://Users//pawan.kumar//PycharmProjects//untitled//u.data")
d = words.flatMap(lambda x:x)
d1 = words.map(lambda x:x.upper())
print(d.count())
print(d1.collect())


#ratings = lines.map(lambda x:x.split()[2])
#print(ratings.countByValue())