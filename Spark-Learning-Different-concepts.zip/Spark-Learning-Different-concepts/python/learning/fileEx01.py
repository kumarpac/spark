from  itertools import islice
'''
#Python Program to read a file
with open("C://Users//pawan.kumar//PycharmProjects//untitled//fakefriends.csv",'r') as fileopen:
    lines = fileopen.readline()
    while lines:
      print(lines)
      lines = fileopen.readline()
'''

'''
#Python program to
def file_read(fname):
    txt = open(fname,'r')
    print(txt.read())

inputdata="C://Users//pawan.kumar//PycharmProjects//untitled//fakefriends.csv"
file_read(inputdata)
'''

'''
def file_read(fname,nlines):
    #txt = open(fname)
    with open(fname,'r') as f:
        for line in islice(f,nlines):
            print(line)
file_read("C://Users//pawan.kumar//PycharmProjects//untitled//fakefriends.csv",1)
'''
'''
def write_file(fname):
    with open(fname,'w') as f:
        f.write("USA\n")
        f.write("Canada")
    txt=open(fname)
    print(txt.read())
write_file("C://Users//pawan.kumar//PycharmProjects//untitled//abc1.txt")
'''
'''
# Print last line of a file
fname="C://Users//pawan.kumar//PycharmProjects//untitled//abc1.txt"
with open(fname,'rb') as f:
    first = f.readline()
    for last in f:
        pass
    print(last)
'''
'''
fname="C://Users//pawan.kumar//PycharmProjects//untitled//abc1.txt"
with open(fname,'rb') as f:
    lines = f.readlines()
    length=len(lines)
    print(lines[-1])

'''
'''
import linecache
fname="C://Users//pawan.kumar//PycharmProjects//untitled//abc1.txt"
with open(fname,'rb') as f:
     print(linecache.getline(fname,2))
'''
def main():
     print("hello world")
print("guru")
main()
