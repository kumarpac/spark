import json
inputfile="C:/input/employee.json"
with open(inputfile,'r') as ffile:
     data = ffile.read()

data1= json.loads(data)
for i in data1:
    print(i)


a = {'lalalala': 3}
myString = json.dumps(a)
print(myString)

