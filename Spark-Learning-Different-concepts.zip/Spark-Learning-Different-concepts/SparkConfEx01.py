from pyspark import SparkConf,SparkContext
import collections
conf = SparkConf().setAppName("Deployment").setMaster('local').set("spark.executor.memory","2g")
sc = SparkContext(conf=conf)
data = sc.textFile("file:///C:/OneDrive/OneDrive - Tredence/Pawan/Pawan Personal/Learning/SparkCourse/u.data")
ratings = data.map(lambda x: x.split()[2])

