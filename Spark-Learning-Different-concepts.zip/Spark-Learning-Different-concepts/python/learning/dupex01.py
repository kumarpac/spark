mylist = ["a","b","a","c","c"]
mylist=list(dict.fromkeys(mylist))
print(mylist)

# initialising dictionary
ini_dict = {'a':1, 'b':2, 'c':3, 'd':2}
#print(str(ini_dict))
rev_dict ={}
for key, value in ini_dict.items():
    rev_dict.setdefault(value,set()).add(key)
result = [key for key,value in rev_dict.items()
                            if (len(value) > 1)]
print("Duplicate values is ", result)