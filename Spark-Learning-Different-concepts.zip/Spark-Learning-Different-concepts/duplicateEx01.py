from pyspark.sql import Row
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("flatmap testing").getOrCreate()
df = spark.sparkContext.parallelize([ \

Row(name='Amit', id=5, marks=80),

Row(name='Amit', id=5, marks=80),

Row(name='Amit', id=10, marks=80)]).toDF()

df.dropDuplicates().show()