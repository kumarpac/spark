from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("find the popular movies").getOrCreate()

lines = spark.sparkContext.textFile("C:/input/u.data")
movies = lines.map(lambda e1:(e1.split()[1],1))
movieCount = movies.reduceByKey(lambda x,y:(x+y))
flipped = movieCount.map( lambda x:(x[1],x[0]))
sorteddata = flipped.sortByKey()
results = sorteddata.collect()
for data in results:
    print(data)


