from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("flatmap testing").getOrCreate()
#data = spark.sparkContext.parallelize([1,2])
#print(data.collect())
acc = spark.sparkContext.accumulator(0)
print(acc.value)
data = spark.sparkContext.textFile("C:/input/flatmap.txt")
mapdata = data.map(lambda e1:e1.split())
print(mapdata.collect())
flatdata = data.flatMap(lambda e1:e1.split())
print("flatmapdata {}" .format(flatdata.collect()))

# flatdatacount = flatdata.map(lambda e1:(e1,1))
# print("flatdatacount {}".format(flatdatacount.collect()))
# countbyvalue = flatdata.countByValue()
# for word,count in countbyvalue.items():
#     print("word = {} count = {} ".format(word,count))