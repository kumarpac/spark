from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("find the popular movies").getOrCreate()

path = spark._gateway.jvm.org.apache.hadoop.fs.Path
FileSystem =spark._gateway.jvm.org.apache.hadoop.fs.FileSystem
Configuration = spark._gateway.jvm.org.apache.hadoop.conf.Configuration
