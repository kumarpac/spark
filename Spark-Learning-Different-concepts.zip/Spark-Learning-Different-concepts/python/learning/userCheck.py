#Data Strcture

#list example
list1 = [1,2,3,4,5,"age",[1,2,3]]
print(list1)
'''
clist =[]
while True:
    input1 = input("Enter number: else type quite\\n")
    if input1 == "quite":
        break
    clist.append(input1)
print("list value {} ".format(clist))

#tuple exmple
tp = (1,2,3)
print(tp)
'''
#dictionary examples
prices_lookup = {'apple':2.99,'orange':1.99,'milk':5.80}
print(prices_lookup)
print(prices_lookup['apple'])
d = {'k1':123,'k2':[0,1,2],'k3':{'insidekey':100}}
print(d)
print(d['k2'])
print(d['k3']['insidekey'])


