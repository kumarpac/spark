from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("mapValue example").getOrCreate()

lines = spark.sparkContext.textFile("C:/input/flatmap.txt")
rdd = lines.flatMap(lambda e1:e1.split())
wordCounts = rdd.countByValue()
for word,count in wordCounts.items():
    print(word,count)