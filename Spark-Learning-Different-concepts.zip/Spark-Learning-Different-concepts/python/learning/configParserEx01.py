import configparser
config = configparser.ConfigParser()
config.read("C:/input/application.properties")

ServerAliveInterval= config.get('DEFAULT','ServerAliveInterval')
print(ServerAliveInterval)