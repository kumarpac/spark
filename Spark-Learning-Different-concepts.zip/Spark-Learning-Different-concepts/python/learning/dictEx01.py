

def sentence_maker(phrase):
    interogatives = ("how","why","what")
    capitalized =  phrase.capitalize()
    if phrase.startswith(interogatives):
        return  "{}?".format(capitalized)
    else:
        return "{}.".format(capitalized)
#print(sentence_maker("hi are you"))

result = []
while True:
    user_input = input("say something: ")
    if user_input == "\end":
        break
    else:
        result.append(sentence_maker(user_input))
print(result)